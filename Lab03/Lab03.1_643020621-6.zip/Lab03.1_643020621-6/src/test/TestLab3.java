package test;
// 643020621-6 นายปฏิเวธ คงสวัสดิ์ SEC 2

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.CartItem;
import main.ShoppingCart;

class TestLab3 {
	
	private ShoppingCart cart;
	@BeforeEach
	public void setup() {
		
		cart = new ShoppingCart();
		
	}
	
	@Test
	@DisplayName("Test OneItemNonDiscount")
	public void OneItemNonDiscount() {
		
		CartItem item1 = new CartItem("Product1",10,10.0,0);
		
		cart.add(item1);
		double exTotalPrice = 100;
		double totalprice = cart.totalPrice();	
		Assertions.assertEquals(exTotalPrice,totalprice);	
	}
	@Test
	@DisplayName("OneItemDiscount")
	public void OneItemDiscount() {
		
		CartItem item1 = new CartItem("Product1",1,100.0,10);
		
		cart.add(item1);
		double exTotalPrice = -900;
		double totalprice = cart.totalPrice();	
		Assertions.assertEquals(exTotalPrice,totalprice);	
	}
	
	@Test
	@DisplayName("Test MannyItemNonDiscount")
	public void MannyItemNonDiscount() {
		
		CartItem item1 = new CartItem("Product1",4,20.0,0);
		CartItem item2 = new CartItem("Product1",4,20.0,0);
		
		cart.add(item1);
		cart.add(item2);
		double exTotalPrice = 160;
		double totalprice = cart.totalPrice();	
		Assertions.assertEquals(exTotalPrice,totalprice);	
	}
	
	@Test
	@DisplayName("Test MannyItemDiscount")
	public void MannyItemDiscount() {
		
		CartItem item1 = new CartItem("Product1",1,70.0,10);
		CartItem item2 = new CartItem("Product1",2,250.0,20);
		
		cart.add(item1);
		cart.add(item2);
		double exTotalPrice = -10130;
		double totalprice = cart.totalPrice();	
		Assertions.assertEquals(exTotalPrice,totalprice);	
	}
	
	
	// negative
	@Test
	@DisplayName("Test price0")
	public void price0() {
		
		CartItem item1 = new CartItem("Product1",10,0.0,0);
		
		cart.add(item1);
		double exTotalPrice = 0;
		double totalprice = cart.totalPrice();	
		Assertions.assertEquals(exTotalPrice,totalprice);	
	}
	
	@Test
	@DisplayName("Test dis100")
	public void dis100() {
		
		CartItem item1 = new CartItem("Product1",1,100.0,100);
		
		cart.add(item1);
		double exTotalPrice = -9900;
		double totalprice = cart.totalPrice();	
		Assertions.assertEquals(exTotalPrice,totalprice);	
	}
	
	@Test
	@DisplayName("Test item0")
	public void item0() {
		
		CartItem item1 = new CartItem("Product1",0,900.0,50);
		
		cart.add(item1);
		double exTotalPrice = 0;
		double totalprice = cart.totalPrice();	
		Assertions.assertEquals(exTotalPrice,totalprice);	
	}
	
	
	
	
	
	
	

	

}

package test;
// 643020598-5 จิรัชญา สือจันทึก
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.CartItem;
import main.ShoppingCart;

class testLab3 {

	ShoppingCart Cart = new ShoppingCart();
	
	@Test
	@DisplayName("Test ProductNotDisc_1")
	public void ProductNotDisc_1() {
		
		CartItem item1 = new CartItem("Doll1",7,550.0,0);
		
		Cart.add(item1);
		double sumPrice = 3850;
		double totalprice = Cart.totalPrice();	
		Assertions.assertEquals(sumPrice,totalprice);	
	}
	
	@Test
	@DisplayName("Test ProductDisc_1")
	public void ProductDisc_1() {
		
		CartItem item1 = new CartItem("Doll2",2,180.0,12);
		
		Cart.add(item1);
		double sumPrice = -3960; 
		double totalprice = Cart.totalPrice();	
		Assertions.assertEquals(sumPrice,totalprice);	
	}
	@Test
	@DisplayName("Test ProductNotDisc_n")
	public void ProductNotDisc_n() {
		
		CartItem item1 = new CartItem("Doll3",3,390.0,0);
		CartItem item2 = new CartItem("Doll4",1,2500.0,0);
		
		Cart.add(item1);
		Cart.add(item2);
		double sumPrice = 3670;
		double totalprice = Cart.totalPrice();	
		Assertions.assertEquals(sumPrice,totalprice);	
	}
	
	@Test
	@DisplayName("Test ProductDisc_n")
	public void ProductDisc_n() {
		
		CartItem item1 = new CartItem("Doll5",2,300.0,24);
		CartItem item2 = new CartItem("Doll6",1,29000.0,70);
		
		Cart.add(item1);
		Cart.add(item2);
		double sumPrice = -2014800;
		double totalprice = Cart.totalPrice();	
		Assertions.assertEquals(sumPrice,totalprice);	
	}
	
	
	@Test
	@DisplayName("Test price_0")
	public void price_0() {
		
		CartItem item1 = new CartItem("Doll7",40,0.0,20);
		
		Cart.add(item1);
		double sumPrice = 0;
		double totalprice = Cart.totalPrice();	
		Assertions.assertEquals(sumPrice,totalprice);	
	}
	
	@Test
	@DisplayName("Test fullDiscount")
	public void fullDiscount() {
		
		CartItem item1 = new CartItem("Doll8",2,1382.0,100);
		
		Cart.add(item1);
		double sumPrice = -273636;
		double totalprice = Cart.totalPrice();	
		Assertions.assertEquals(sumPrice,totalprice);	
	}
	
	@Test
	@DisplayName("Test product_0")
	public void product_0() {
		
		CartItem item1 = new CartItem("Doll9",0,12900.0,100);
		
		Cart.add(item1);
		double sumPrice = 0;
		double totalprice = Cart.totalPrice();	
		Assertions.assertEquals(sumPrice,totalprice);	
	}
	
}

package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.CartItem;
import main.ShoppingCart;

class TestLab3 {
	
	private ShoppingCart cart;
	@BeforeEach
	public void setup() {
		
		cart = new ShoppingCart();
		
		
		
	}
	
	@Test
	@DisplayName("Test TotalPrice")
	public void Testtotalprice() {
		
		CartItem item1 = new CartItem("Product1",10,10.0,0);
		
		
		
		
		cart.add(item1);
		
		double exTotalPrice = 100;
		double totalprice = cart.totalPrice();
		
		Assertions.assertEquals(exTotalPrice,totalprice);
		
		
		
	}
	
	
	
	
	
	
	
	
	
	

	

}
